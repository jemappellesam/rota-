const express = require("express");
const fs = require("fs");
const path = require("path"); // Importar o módulo path
const app = express();

// Configurar EJS como engine de visualização
app.set('view engine', 'ejs');

// Servir arquivos estáticos da pasta "public"
app.use(express.static(path.join(__dirname, 'public')));

// Rota para a página inicial
app.get('/', (req, res) => {
    fs.readFile('pontuacao.json', 'utf8', (erro, dados) => {
        if (erro) {
            console.error("Erro ao ler o arquivo pontuacao.json:", erro);
            return res.status(500).send("Erro ao ler as pontuações.");
        }

        let escolas = [];
        try {
            escolas = JSON.parse(dados);
        } catch (parseError) {
            console.error("Erro ao analisar JSON:", parseError);
            return res.status(500).send("Erro ao analisar as pontuações.");
        }

        // Ordenar as escolas pela pontuação em ordem decrescente
        escolas.sort((a, b) => b.pontos - a.pontos);

        // Separar as cinco melhores escolas e as demais
        const melhoresEscolas = escolas.slice(0, 5);
        const outrasEscolas = escolas.slice(5);

        res.render('template', {
            title: 'Painel',
            escolas: melhoresEscolas,
            equipes: outrasEscolas
        });
    });
});

app.listen(3000, () => {
    console.log("Servidor está escutando na porta 3000...");
});
